package com.tweetApp.tweet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwitterApplicationTests {

	@Test
	void contextLoads() {
	}

}
